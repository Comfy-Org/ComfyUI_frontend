import { expect, test } from '@playwright/test'
import type { Page } from '@playwright/test'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'

const DIR = 'http://localhost:4431'
const PAGES = 'http://localhost:4432'
const SHOTS = '../shots'
const record = (k: string, v: unknown) => {
  const measured: Record<string, unknown> = existsSync('../measured.json')
    ? JSON.parse(readFileSync('../measured.json', 'utf8'))
    : {}
  measured[k] = v
  writeFileSync('../measured.json', JSON.stringify(measured, null, 2))
}

const DESKTOP = { width: 1440, height: 900 }
const MOBILE = { width: 390, height: 844 }

async function waitImages(page: Page) {
  await page.evaluate(async () => {
    for (const img of Array.from(document.images)) {
      img.loading = 'eager'
    }
    await Promise.all(
      Array.from(document.images).map((img) =>
        img.complete
          ? null
          : new Promise((r) => {
              img.onload = r
              img.onerror = r
            })
      )
    )
  })
}

async function shot(page: Page, name: string, fullPage = true) {
  await waitImages(page)
  await page.screenshot({ path: `${SHOTS}/${name}.png`, fullPage })
}

async function directoryCards(page: Page) {
  return page.locator('main ul.grid > li > a').evaluateAll((links) =>
    links.map((a) => {
      const img = a.querySelector('img')
      const spans = a.querySelectorAll(':scope > span > span')
      return {
        href: a.getAttribute('href'),
        target: a.getAttribute('target'),
        avatar: img
          ? { src: img.getAttribute('src'), loaded: img.naturalWidth > 0 }
          : { initial: a.firstElementChild?.textContent?.trim() },
        name: spans[0]?.textContent?.trim(),
        meta: spans[1]?.textContent?.replace(/\s+/g, ' ').trim()
      }
    })
  )
}

test.describe('PR 21456 directory', () => {
  for (const [label, viewport] of [
    ['desktop', DESKTOP],
    ['mobile', MOBILE]
  ] as const) {
    test(`directory ${label}`, async ({ page }) => {
      await page.setViewportSize(viewport)
      const res = await page.goto(`${DIR}/hub/creators/`)
      expect(res?.status()).toBe(200)
      await waitImages(page)
      const cards = await directoryCards(page)
      record(`21456.directory.${label}`, cards)
      expect(cards).toHaveLength(15)
      for (const c of cards) {
        expect(c.name).toBeTruthy()
        expect(c.meta).toMatch(/^@[a-z0-9._-]+ · \d+ workflows?$/)
        expect(c.href).toMatch(/^https:\/\/comfy\.org\/workflows\/[^/]+\/$/)
        if ('loaded' in c.avatar) expect(c.avatar.loaded).toBe(true)
        else expect(c.avatar.initial).toHaveLength(1)
      }
      const sorted = cards
        .map((c) => {
          const m = c.meta!.match(/^@(\S+) · (\d+)/)!
          return { u: m[1], n: Number(m[2]) }
        })
      const expected = [...sorted].sort(
        (a, b) => b.n - a.n || a.u.localeCompare(b.u)
      )
      expect(sorted).toEqual(expected)
      await shot(page, `21456-directory-${label}`)
    })
  }

  test('hub models page for design comparison', async ({ page }) => {
    await page.setViewportSize(DESKTOP)
    await page.goto(`${DIR}/hub/models/`)
    await shot(page, '21456-hub-models-desktop', false)
    await page.goto(`${DIR}/hub/creators/`)
    await shot(page, '21456-directory-desktop-fold', false)
    await page.setViewportSize(MOBILE)
    await page.goto(`${DIR}/hub/models/`)
    await shot(page, '21456-hub-models-mobile', false)
  })

  test('vfx page renders HubWorkflowCard', async ({ page }) => {
    await page.setViewportSize(DESKTOP)
    await page.goto(`${DIR}/solutions/vfx/`)
    const cards = page.getByTestId('hub-card')
    record('21456.vfx.cardCount', await cards.count())
    await expect(cards.first()).toBeVisible()
    record(
      '21456.vfx.authorLinks',
      await page.locator('[data-testid="hub-card"] a[href*="/workflows/"], [data-testid="hub-card"] a[href*="/hub/creators/"]').count()
    )
    await cards.first().scrollIntoViewIfNeeded()
    await waitImages(page)
    await page
      .locator('[data-testid="hub-card"]')
      .first()
      .locator('xpath=ancestor::section[1]')
      .screenshot({ path: `${SHOTS}/21456-vfx-cards.png` })
  })
})

async function profileHeader(page: Page) {
  return page.locator('main').evaluate((main) => {
    const header = main.querySelector('header')!
    const img = header.querySelector('img')
    return {
      avatar: img
        ? { src: img.getAttribute('src'), loaded: img.naturalWidth > 0 }
        : { initial: header.firstElementChild?.textContent?.trim() },
      name: header.querySelector('h1')?.textContent?.trim(),
      meta: header
        .querySelector('h1 + p')
        ?.textContent?.replace(/\s+/g, ' ')
        .trim(),
      bio: header.nextElementSibling?.tagName === 'P'
        ? header.nextElementSibling.textContent?.trim().slice(0, 120)
        : null,
      cards: main.querySelectorAll('[data-testid="hub-card"]').length
    }
  })
}

async function head(page: Page) {
  return page.evaluate(() => {
    const ld = Array.from(
      document.querySelectorAll('script[type="application/ld+json"]')
    ).map((s) => JSON.parse(s.textContent!))
    const nodes = ld.flatMap((d) => d['@graph'] ?? [d])
    return {
      title: document.title,
      description: document
        .querySelector('meta[name="description"]')
        ?.getAttribute('content'),
      canonical: document
        .querySelector('link[rel="canonical"]')
        ?.getAttribute('href'),
      robots: document
        .querySelector('meta[name="robots"]')
        ?.getAttribute('content'),
      nodes: nodes.map((n) => ({
        type: n['@type'],
        id: n['@id'],
        name: n.name,
        url: n.url,
        sameAs: n.sameAs,
        mainEntity: n.mainEntity
      }))
    }
  })
}

async function hydrated(page: Page) {
  await page.getByTestId('hub-load-more').scrollIntoViewIfNeeded()
  await expect(page.locator('astro-island[ssr]')).toHaveCount(0)
}

test.describe('PR 21457 profiles', () => {
  for (const user of ['purz', 'comfyui']) {
    for (const [label, viewport] of [
      ['desktop', DESKTOP],
      ['mobile', MOBILE]
    ] as const) {
      test(`${user} profile ${label}`, async ({ page }) => {
        await page.setViewportSize(viewport)
        const res = await page.goto(`${PAGES}/hub/creators/${user}/`)
        expect(res?.status()).toBe(200)
        await waitImages(page)
        const h = await profileHeader(page)
        record(`21457.${user}.header.${label}`, h)
        expect(h.name).toBeTruthy()
        expect(h.meta).toMatch(new RegExp(`^@${user} · \\d+ workflows$`))
        expect(h.cards).toBe(24)
        if ('loaded' in h.avatar) expect(h.avatar.loaded).toBe(true)
        if (label === 'desktop') {
          const hd = await head(page)
          record(`21457.${user}.head`, {
            ...hd,
            descriptionLength: hd.description?.length
          })
          expect(hd.description!.length).toBeLessThanOrEqual(160)
          const ogUrl = await page
            .locator('meta[property="og:url"]')
            .getAttribute('content')
          record(`21457.${user}.ogUrl`, ogUrl)
          expect(ogUrl).toBe(`https://comfy.org/hub/creators/${user}/`)
          const types = hd.nodes.map((n) => n.type)
          expect(types).toContain('ProfilePage')
          expect(types).toContain(user === 'comfyui' ? 'Organization' : 'Person')
          await shot(page, `21457-${user}-desktop-fold`, false)
        }
        if (label === 'mobile')
          await shot(page, `21457-${user}-mobile-fold`, false)
        await shot(page, `21457-${user}-${label}`)
      })
    }
  }

  test('purz Load more: one request, disabled while loading', async ({
    page
  }) => {
    await page.setViewportSize(DESKTOP)
    const jsonRequests: string[] = []
    page.on('request', (r) => {
      if (r.url().includes('/hub/creators/') && r.url().endsWith('.json'))
        jsonRequests.push(r.url())
    })
    let release!: () => void
    const gate = new Promise<void>((r) => (release = r))
    await page.route('**/hub/creators/purz.json', async (route) => {
      await gate
      await route.continue()
    })
    await page.goto(`${PAGES}/hub/creators/purz/`)
    await hydrated(page)
    const button = page.getByTestId('hub-load-more')
    await button.click()
    await expect(button).toBeDisabled()
    await button.click({ force: true }).catch(() => {})
    await button.click({ force: true }).catch(() => {})
    await waitImages(page)
    await button.screenshot({ path: `${SHOTS}/21457-loadmore-disabled.png` })
    await page.screenshot({
      path: `${SHOTS}/21457-loadmore-disabled-page.png`
    })
    release()
    await expect(page.getByTestId('hub-card')).toHaveCount(26)
    await expect(button).toHaveCount(0)
    record('21457.purz.loadMore', {
      requests: jsonRequests,
      cardsAfter: await page.getByTestId('hub-card').count()
    })
    expect(jsonRequests).toEqual([`${PAGES}/hub/creators/purz.json`])
    await shot(page, '21457-purz-after-loadmore', false)
  })

  test('comfyui Load more until done', async ({ page }) => {
    await page.setViewportSize(DESKTOP)
    const jsonRequests: string[] = []
    page.on('request', (r) => {
      if (r.url().includes('/hub/creators/') && r.url().endsWith('.json'))
        jsonRequests.push(r.url())
    })
    await page.goto(`${PAGES}/hub/creators/comfyui/`)
    await hydrated(page)
    const button = page.getByTestId('hub-load-more')
    const counts: number[] = [await page.getByTestId('hub-card').count()]
    let clicks = 0
    while ((await button.count()) > 0 && clicks < 40) {
      const before = counts[counts.length - 1]
      await button.click()
      clicks++
      await expect
        .poll(() => page.getByTestId('hub-card').count())
        .toBeGreaterThan(before)
      counts.push(await page.getByTestId('hub-card').count())
      if (clicks === 3) {
        await page.getByTestId('hub-card').last().scrollIntoViewIfNeeded()
        await waitImages(page)
        await page.screenshot({ path: `${SHOTS}/21457-comfyui-page4.png` })
      }
    }
    record('21457.comfyui.loadMore', { clicks, counts, requests: jsonRequests })
    expect(counts[counts.length - 1]).toBe(456)
    await expect(button).toHaveCount(0)
    expect(jsonRequests).toEqual([`${PAGES}/hub/creators/comfyui.json`])
    await page.getByTestId('hub-card').last().scrollIntoViewIfNeeded()
    await waitImages(page)
    await page.screenshot({ path: `${SHOTS}/21457-comfyui-end.png` })
  })

  test('directory card opens profile in same tab', async ({ page }) => {
    await page.setViewportSize(DESKTOP)
    await page.goto(`${PAGES}/hub/creators/`)
    const cards = await directoryCards(page)
    record('21457.directory.cards', cards)
    expect(cards).toHaveLength(15)
    for (const c of cards) {
      expect(c.href).toMatch(/^\/hub\/creators\/[a-z0-9._-]+\/$/)
      expect(c.target).toBeNull()
    }
    await shot(page, '21457-directory-desktop', false)
    const link = page.locator('main ul.grid > li > a[href="/hub/creators/purz/"]')
    const pagesBefore = page.context().pages().length
    await link.click()
    await page.waitForURL(`${PAGES}/hub/creators/purz/`)
    record('21457.directory.click', {
      url: page.url(),
      tabsBefore: pagesBefore,
      tabsAfter: page.context().pages().length
    })
    expect(page.context().pages()).toHaveLength(pagesBefore)
    await shot(page, '21457-directory-click-purz', false)
  })

  test('unknown creator is 404', async ({ page }) => {
    await page.setViewportSize(DESKTOP)
    const res = await page.goto(`${PAGES}/hub/creators/not-a-real-creator/`)
    record('21457.unknown.status', res?.status())
    expect(res?.status()).toBe(404)
    await shot(page, '21457-unknown-404', false)
  })
})
