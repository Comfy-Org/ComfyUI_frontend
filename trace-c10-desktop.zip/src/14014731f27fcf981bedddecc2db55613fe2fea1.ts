import { mkdirSync, writeFileSync } from 'node:fs'
import path from 'node:path'

import { expect, test } from '@playwright/test'
import type { Locator, Page } from '@playwright/test'

const PR = 'http://127.0.0.1:4411'
const BASE = 'http://127.0.0.1:4422'
const DIR = path.dirname(new URL(import.meta.url).pathname)
const SHOTS = path.join(DIR, 'shots')
const MEASURES = path.join(DIR, 'measures')
mkdirSync(SHOTS, { recursive: true })
mkdirSync(MEASURES, { recursive: true })

const shot = (name: string) => path.join(SHOTS, `${name}.png`)
const record = (id: string, data: unknown) =>
  writeFileSync(
    path.join(MEASURES, `${id}.json`),
    JSON.stringify(data, null, 2)
  )

async function open(page: Page, url: string) {
  await page.goto(url, { waitUntil: 'load' })
}

async function hydrated(target: Locator) {
  await expect
    .poll(() =>
      target.evaluate(
        (el) => !el.closest('astro-island')?.hasAttribute('ssr')
      )
    )
    .toBe(true)
}

async function imagesLoaded(scope: Locator) {
  await expect
    .poll(() =>
      scope.evaluate((root) =>
        [...root.querySelectorAll('img')].every(
          (img) => img.complete && img.naturalWidth > 0
        )
      )
    )
    .toBe(true)
}

const cardLink = (page: Page, title: string) =>
  page.locator('a', { hasText: title }).first()

const handleLeft = (card: Locator) =>
  card
    .getByTestId('compare-handle')
    .evaluate((el) => parseFloat((el as HTMLElement).style.left))

async function showCard(page: Page, card: Locator) {
  await card.evaluate((el) =>
    el.scrollIntoView({ block: 'center', inline: 'nearest' })
  )
  await hydrated(card)
  await imagesLoaded(card)
}

test('C1 desktop pointer drags the compare line to both sides @desktop', async ({
  page
}) => {
  await open(page, `${PR}/hub/workflows`)
  const card = cardLink(page, 'QA Compare Slider')
  await showCard(page, card)
  const media = card.getByTestId('model-card-media')
  const box = (await media.boundingBox())!
  const y = box.y + box.height / 2

  await page.mouse.move(box.x + box.width * 0.15, y, { steps: 6 })
  await expect.poll(() => handleLeft(card)).toBeCloseTo(15, 0)
  const left = await handleLeft(card)
  await page.screenshot({ path: shot('c1-desktop-left') })

  await page.mouse.move(box.x + box.width * 0.85, y, { steps: 12 })
  await expect.poll(() => handleLeft(card)).toBeCloseTo(85, 0)
  const right = await handleLeft(card)
  await page.screenshot({ path: shot('c1-desktop-right') })
  record('c1', { handleLeftAt15: left, handleLeftAt85: right })
})

test('C2 desktop click on the compare image opens the workflow @desktop', async ({
  page
}) => {
  await open(page, `${PR}/hub/workflows`)
  const card = cardLink(page, 'QA Compare Slider')
  await showCard(page, card)
  const href = await card.getAttribute('href')
  const media = card.getByTestId('model-card-media')
  const box = (await media.boundingBox())!
  const x = box.x + box.width * 0.3
  const y = box.y + box.height / 2
  await page.mouse.move(x, y, { steps: 4 })
  await page.screenshot({ path: shot('c2-desktop-before-click') })
  const from = page.url()
  await page.mouse.click(x, y)
  await expect(page).toHaveURL(new URL(href!, PR).toString())
  record('c2', { href, from, to: page.url() })
})

test('C3 mobile touch drag moves the line and leaves the row still @mobile', async ({
  page,
  context
}) => {
  await open(page, `${PR}/hub/workflows`)
  const card = cardLink(page, 'QA Compare Slider')
  await showCard(page, card)
  const cdp = await context.newCDPSession(page)
  const media = card.getByTestId('model-card-media')
  const box = (await media.boundingBox())!
  const y = Math.round(box.y + box.height / 2)
  const scrollLeft = () =>
    card.evaluate((a) => {
      let el = a.parentElement
      while (
        el &&
        !(
          el.scrollWidth > el.clientWidth + 2 &&
          /auto|scroll/.test(getComputedStyle(el).overflowX)
        )
      )
        el = el.parentElement
      return el ? el.scrollLeft : null
    })
  const drag = async (fromPct: number, toPct: number) => {
    const steps = 14
    const xs = Array.from({ length: steps + 1 }, (_, i) =>
      Math.round(box.x + box.width * (fromPct + ((toPct - fromPct) * i) / steps))
    )
    await cdp.send('Input.dispatchTouchEvent', {
      type: 'touchStart',
      touchPoints: [{ x: xs[0], y }]
    })
    for (const x of xs.slice(1))
      await cdp.send('Input.dispatchTouchEvent', {
        type: 'touchMove',
        touchPoints: [{ x, y }]
      })
    await cdp.send('Input.dispatchTouchEvent', {
      type: 'touchEnd',
      touchPoints: []
    })
  }

  const url0 = page.url()
  const scroll0 = await scrollLeft()
  const handle0 = await handleLeft(card)

  await drag(0.6, 0.02)
  await expect.poll(() => handleLeft(card)).toBeLessThan(20)
  const leftHandle = await handleLeft(card)
  const scroll1 = await scrollLeft()
  await page.screenshot({ path: shot('c3-mobile-left') })

  await drag(0.4, 0.98)
  await expect.poll(() => handleLeft(card)).toBeGreaterThan(80)
  const rightHandle = await handleLeft(card)
  const scroll2 = await scrollLeft()
  await page.screenshot({ path: shot('c3-mobile-right') })

  expect(scroll1).toBe(scroll0)
  expect(scroll2).toBe(scroll0)
  expect(page.url()).toBe(url0)
  record('c3', {
    handle: [handle0, leftHandle, rightHandle],
    rowScrollLeft: [scroll0, scroll1, scroll2],
    url: [url0, page.url()]
  })
})

async function diffPixels(page: Page, a: Buffer, b: Buffer) {
  return page.evaluate(
    async ([da, db]) => {
      const load = (src: string) =>
        new Promise<HTMLImageElement>((resolve) => {
          const img = new Image()
          img.onload = () => resolve(img)
          img.src = src
        })
      const [ia, ib] = await Promise.all([load(da), load(db)])
      if (ia.width !== ib.width || ia.height !== ib.height)
        return {
          sizeA: [ia.width, ia.height],
          sizeB: [ib.width, ib.height],
          diff: -1,
          total: 0
        }
      const pixels = (img: HTMLImageElement) => {
        const c = document.createElement('canvas')
        c.width = img.width
        c.height = img.height
        const ctx = c.getContext('2d')!
        ctx.drawImage(img, 0, 0)
        return ctx.getImageData(0, 0, img.width, img.height).data
      }
      const pa = pixels(ia)
      const pb = pixels(ib)
      let diff = 0
      for (let i = 0; i < pa.length; i += 4)
        if (
          pa[i] !== pb[i] ||
          pa[i + 1] !== pb[i + 1] ||
          pa[i + 2] !== pb[i + 2] ||
          pa[i + 3] !== pb[i + 3]
        )
          diff++
      return {
        sizeA: [ia.width, ia.height],
        sizeB: [ib.width, ib.height],
        diff,
        total: pa.length / 4
      }
    },
    [
      `data:image/png;base64,${a.toString('base64')}`,
      `data:image/png;base64,${b.toString('base64')}`
    ]
  )
}

for (const tag of ['@desktop', '@mobile'])
  test(`C4 one-image card is pixel-identical to base ${tag}`, async ({
    page
  }, info) => {
    const surface = info.project.name
    const crops: Record<string, Buffer> = {}
    for (const [tree, origin] of [
      ['pr', PR],
      ['base', BASE]
    ]) {
      await open(page, `${origin}/hub/workflows`)
      await page.mouse.move(1, 1)
      const card = cardLink(page, 'QA Plain')
      await showCard(page, card)
      crops[tree] = await card.screenshot({ animations: 'disabled' })
      writeFileSync(shot(`c4-${surface}-${tree}-card`), crops[tree])
      await page.screenshot({ path: shot(`c4-${surface}-${tree}`) })
    }
    await page.goto('about:blank')
    const result = await diffPixels(page, crops.pr, crops.base)
    record(`c4-${surface}`, {
      ...result,
      bytesIdentical: crops.pr.equals(crops.base),
      tolerance: 0
    })
    expect(result.sizeA).toEqual(result.sizeB)
    expect(result.diff).toBe(0)
  })

test('C5 hover dissolve shows the second image @desktop', async ({ page }) => {
  await open(page, `${PR}/hub/workflows`)
  const card = cardLink(page, 'QA Hover Dissolve')
  await showCard(page, card)
  const second = card.locator('img[alt$=" - 2"]')
  const opacity = () => second.evaluate((el) => getComputedStyle(el).opacity)
  const before = await opacity()
  await card.getByTestId('model-card-media').hover()
  await expect.poll(opacity).toBe('1')
  await page.screenshot({ path: shot('c5-hover-dissolve') })
  record('c5', { opacityBefore: before, opacityHovered: await opacity() })
  expect(before).toBe('0')
})

test('C6 zoom hover scales to 1.25, default card to 1.05 @desktop', async ({
  page
}) => {
  await open(page, `${PR}/hub/workflows`)
  const zoom = cardLink(page, 'QA Zoom Hover')
  await showCard(page, zoom)
  const zoomImg = zoom.getByTestId('model-card-media')
  const scaleOf = (img: Locator) =>
    img.evaluate((el) => getComputedStyle(el).scale)
  const zoomRest = await scaleOf(zoomImg)
  await zoom.hover()
  await expect.poll(() => scaleOf(zoomImg)).toBe('1.25')
  await page.screenshot({ path: shot('c6-zoom-hover') })

  const plain = cardLink(page, 'QA Plain')
  const plainImg = plain.getByTestId('model-card-media')
  await plain.hover()
  await expect.poll(() => scaleOf(plainImg)).toBe('1.05')
  record('c6', {
    zoomRest,
    zoomHovered: '1.25',
    plainHovered: await scaleOf(plainImg)
  })
})

test('C7 video comparison renders no slider @desktop', async ({ page }) => {
  await open(page, `${PR}/hub/workflows`)
  const card = cardLink(page, 'QA Video Comparison')
  await showCard(page, card)
  const media = card.getByTestId('model-card-media')
  await expect(card.getByTestId('compare-handle')).toHaveCount(0)
  await expect(card.getByRole('slider')).toHaveCount(0)
  await expect(media).toHaveCount(1)
  const tag = await media.evaluate((el) => el.tagName)
  expect(tag).toBe('IMG')
  await page.screenshot({ path: shot('c7-video-comparison') })
  record('c7', { mediaTag: tag, handles: 0 })
})

test('C8 zh-CN compare alts are translated @desktop', async ({ page }) => {
  await open(page, `${PR}/zh-CN/hub/workflows`)
  const card = cardLink(page, 'QA Compare Slider')
  await showCard(page, card)
  const alts = await card
    .locator('img')
    .evaluateAll((imgs) => imgs.map((i) => (i as HTMLImageElement).alt))
  expect(alts.some((a) => a.includes('处理后'))).toBe(true)
  expect(alts.some((a) => a.includes('处理前'))).toBe(true)
  await page.screenshot({ path: shot('c8-zh-cn') })
  record('c8', { url: page.url(), alts })
})

test('C9 Tab passes the compare card without a stop inside @desktop', async ({
  page
}) => {
  await open(page, `${PR}/hub/workflows`)
  const card = cardLink(page, 'QA Compare Slider')
  const next = cardLink(page, 'QA Hover Dissolve')
  await showCard(page, card)
  await card.focus()
  await page.keyboard.press('Shift+Tab')
  const describe = () =>
    page.evaluate(() => {
      const a = document.activeElement as HTMLElement
      return `${a.tagName} ${a.getAttribute('href') ?? ''} ${(a.textContent ?? '').trim().slice(0, 30)}`
    })
  const beforeEl = await describe()
  await page.keyboard.press('Tab')
  await expect(card).toBeFocused()
  await page.screenshot({ path: shot('c9-compare-focused') })
  await page.keyboard.press('Tab')
  await expect(next).toBeFocused()
  await page.screenshot({ path: shot('c9-next-focused') })
  const tabbablesInside = await card.evaluate(
    (a) =>
      a.querySelectorAll('[tabindex]:not([tabindex="-1"]), button, input, [role=slider]')
        .length
  )
  expect(tabbablesInside).toBe(0)
  record('c9', { beforeEl, afterTab1: 'compare card link', afterTab2: await describe(), tabbablesInside })
})

test('C10 static Hub slider keeps keyboard control @desktop', async ({
  page
}) => {
  await open(page, `${PR}/solutions/vfx`)
  const slider = page.getByRole('slider').first()
  await slider.scrollIntoViewIfNeeded()
  await hydrated(slider)
  await expect(slider).toHaveAttribute('aria-valuenow', '50')
  await slider.focus()
  await page.keyboard.press('ArrowRight')
  await page.keyboard.press('ArrowRight')
  await expect(slider).toHaveAttribute('aria-valuenow', '54')
  await page.screenshot({ path: shot('c10-vfx-slider') })
  record('c10', {
    sliders: await page.getByRole('slider').count(),
    valuenow: await slider.getAttribute('aria-valuenow')
  })
})
