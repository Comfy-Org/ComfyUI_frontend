import type { Request } from '@playwright/test'

import type {
  ExchangeTokenRequest,
  ListMembersResponse
} from '@comfyorg/ingest-types'
import { zExchangeTokenRequest } from '@comfyorg/ingest-types/zod'

import type { RemoteConfig } from '@/platform/remoteConfig/types'

import { comfyPageFixture } from '@e2e/fixtures/ComfyPage'
import {
  WEB_SESSION,
  WEB_SESSION_COOKIE,
  WEB_SESSION_ANONYMOUS_FEATURES,
  WEB_SESSION_FEATURES,
  WEB_SESSION_MINT,
  currentWorkspace
} from '@e2e/fixtures/data/webSession'
import {
  TEAM_WORKSPACE,
  WORKSPACE_SWITCHER_WORKSPACES
} from '@e2e/fixtures/data/workspaceSwitcher'
import { mockBilling } from '@e2e/fixtures/utils/cloudBillingMocks'
import { jsonRoute } from '@e2e/fixtures/utils/jsonRoute'
import { mockWorkspaceList } from '@e2e/fixtures/utils/workspaceMocks'

const APP_URL = process.env.PLAYWRIGHT_TEST_URL || 'http://localhost:8188'

interface TokenMint {
  body: ExchangeTokenRequest
  authorization: string | undefined
  workspace: string | undefined
}

interface WebSessionFixtures {
  /** Flags merged into both `/api/features` answers, over the backend's. */
  serverFeatures: RemoteConfig
  tokenMints: TokenMint[]
  workspaceReads: Request[]
  firebaseRequests: string[]
  credentialedFeatureReads: Request[]
}

export const webSessionTest = comfyPageFixture.extend<WebSessionFixtures>({
  serverFeatures: [{}, { option: true }],
  tokenMints: async ({ context }, use) => {
    const mints: TokenMint[] = []
    context.on('request', (request) => {
      if (new URL(request.url()).pathname.startsWith('/api/auth/token')) {
        const headers = request.headers()
        mints.push({
          body: zExchangeTokenRequest.parse(request.postDataJSON()),
          authorization: headers['authorization'],
          workspace: headers['x-comfy-workspace-id']
        })
      }
    })
    await use(mints)
  },
  credentialedFeatureReads: async ({ context }, use) => {
    const reads: Request[] = []
    context.on('request', (request) => {
      if (
        new URL(request.url()).pathname === '/api/features' &&
        'x-comfy-client' in request.headers()
      ) {
        reads.push(request)
      }
    })
    await use(reads)
  },
  firebaseRequests: async ({ context }, use) => {
    const urls: string[] = []
    context.on('request', (request) => {
      const { hostname } = new URL(request.url())
      if (
        hostname === 'securetoken.googleapis.com' ||
        hostname === 'identitytoolkit.googleapis.com'
      ) {
        urls.push(request.url())
      }
    })
    await use(urls)
  },
  workspaceReads: async ({ context }, use) => {
    const reads: Request[] = []
    context.on('request', (request) => {
      const { pathname } = new URL(request.url())
      if (
        request.method() === 'GET' &&
        pathname === '/api/workspaces/current'
      ) {
        reads.push(request)
      }
    })
    await use(reads)
  },
  page: async (
    {
      page,
      context,
      serverFeatures,
      tokenMints,
      workspaceReads,
      firebaseRequests,
      credentialedFeatureReads
    },
    use
  ) => {
    void tokenMints
    void firebaseRequests
    void credentialedFeatureReads
    void workspaceReads

    await page.route('**/api/features', async (route) => {
      const response = await route.fetch()
      const backendFeatures: RemoteConfig = await response.json()
      const headers = await route.request().allHeaders()
      const credentialed =
        'x-comfy-client' in headers &&
        'cookie' in headers &&
        headers['cookie'].includes(WEB_SESSION_COOKIE.name)
      await route.fulfill(
        jsonRoute(
          credentialed
            ? { ...backendFeatures, ...WEB_SESSION_FEATURES, ...serverFeatures }
            : {
                ...backendFeatures,
                ...WEB_SESSION_ANONYMOUS_FEATURES,
                ...serverFeatures
              }
        )
      )
    })

    await page.route('**/api/auth/session', async (route) => {
      if (route.request().method() !== 'GET') return route.fallback()
      await route.fulfill(jsonRoute(WEB_SESSION))
    })

    await page.route('**/api/auth/token', (route) =>
      route.fulfill(jsonRoute(WEB_SESSION_MINT))
    )

    await mockBilling(page, { workspaceId: TEAM_WORKSPACE.id })

    await mockWorkspaceList(page, WORKSPACE_SWITCHER_WORKSPACES)

    await page.route('**/api/workspace/members**', (route) =>
      route.fulfill({
        json: {
          members: [],
          pagination: { offset: 0, limit: 50, total: 0, has_more: false }
        } satisfies ListMembersResponse
      })
    )

    await page.route('**/api/workspaces/current', async (route) => {
      const workspaceId = await route
        .request()
        .headerValue('x-comfy-workspace-id')
      const workspace = WORKSPACE_SWITCHER_WORKSPACES.find(
        ({ id }) => id === workspaceId
      )
      if (!workspace) {
        await route.fulfill({ status: 404 })
        return
      }
      await route.fulfill(jsonRoute(currentWorkspace(workspace)))
    })

    await context.addCookies([{ ...WEB_SESSION_COOKIE, url: APP_URL }])

    try {
      await use(page)
    } finally {
      await page.unrouteAll({ behavior: 'ignoreErrors' })
    }
  }
})
