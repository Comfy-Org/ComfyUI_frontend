import { expect, mergeTests } from '@playwright/test'
import type { Page } from '@playwright/test'

import type { RemoteConfig } from '@/platform/remoteConfig/types'
import type { BillingStatusResponse } from '@/platform/workspace/api/workspaceApi'
import { AGENT_CONSENT_SETTING_ID } from '@/platform/settings/constants/agent'
import { TOUR_ROLE_PINS } from '@/renderer/extensions/firstRunTour/roles/tourRolePins'

import { comfyPageFixture } from '@e2e/fixtures/ComfyPage'
import { onboardingFixture } from '@e2e/fixtures/tourFixture'
import { jsonRoute } from '@e2e/fixtures/utils/jsonRoute'

const test = mergeTests(comfyPageFixture, onboardingFixture)

const SHOTS = process.env.QA_SHOTS_DIR ?? 'qa-shots'
const BUILD = process.env.QA_BUILD ?? 'branch'
const PREFIX = 'getting-started-card-'

const FLAGS: RemoteConfig = {
  onboarding_tour_enabled: true,
  subscription_required: true,
  'agent-in-app-experience': true
}

const ACTIVE: BillingStatusResponse = {
  is_active: true,
  max_seats: 1,
  occupied_seats: 1,
  team_credit_stop: null,
  scheduled_change: null,
  subscription_tier: 'PRO',
  subscription_duration: 'MONTHLY',
  renewal_date: '2099-01-01',
  has_funds: true
}

async function skipTourToNudge(page: Page) {
  await expect(page.getByRole('dialog', { name: /./ }).first()).toBeVisible()
  const ids = await page
    .locator(`[data-testid^="${PREFIX}"]`)
    .evaluateAll((cards) => cards.map((c) => c.getAttribute('data-testid')))
  const pinned = ids
    .map((id) => id!.slice(PREFIX.length))
    .find((id) => Object.hasOwn(TOUR_ROLE_PINS, id))
  await page.getByTestId(`${PREFIX}${pinned}`).click()
  await expect(page.getByTestId('coach-spotlight')).toBeVisible()
  await page.keyboard.press('Escape')
  await expect(page.getByTestId('coach-spotlight')).toBeHidden()
}

async function hideToasts(page: Page) {
  await page.addStyleTag({
    content:
      '.p-toast,[data-pc-name="toast"],.comfy-toast,.p-toast-message{display:none!important}'
  })
}

function overlaps(
  a: { x: number; y: number; width: number; height: number },
  b: { x: number; y: number; width: number; height: number }
) {
  return (
    a.x < b.x + b.width &&
    a.x + a.width > b.x &&
    a.y < b.y + b.height &&
    a.y + a.height > b.y
  )
}

test.describe('QA: first-run nudge', { tag: ['@cloud', '@ui'] }, () => {
  test.use({
    viewport: { width: 1440, height: 900 },
    initialSettings: {
      'Comfy.TutorialCompleted': false,
      'Comfy.OnboardingCoachmarks.Seen': ['appMode']
    },
    initialFeatureFlags: { onboarding_tour_enabled: true }
  })

  test.beforeEach(async ({ page }) => {
    await page.addInitScript(() =>
      localStorage.setItem('Comfy.AgentPanel.onboarded', 'true')
    )
    await page.route('**/api/features', (r) => r.fulfill(jsonRoute(FLAGS)))
    await page.route('**/api/billing/status', (r) =>
      r.fulfill(jsonRoute(ACTIVE))
    )
    await page.route('**/api/assets**', (r) =>
      r.fulfill(jsonRoute({ assets: [], total: 0, has_more: false }))
    )
    await page.route(`**/api/global-settings/${AGENT_CONSENT_SETTING_ID}`, (r) =>
      r.fulfill(
        jsonRoute({
          key: AGENT_CONSENT_SETTING_ID,
          value: true,
          updated_at: '2026-09-09T00:00:00Z'
        })
      )
    )
  })

  test('nudge with the agent panel docked', async ({ comfyPage }) => {
    const { page } = comfyPage
    await skipTourToNudge(page)
    const panel = page.locator('#agent-panel-root')
    const nudge = page.getByTestId('first-run-nudge')
    await expect(panel).toBeVisible()
    await expect(nudge).toBeVisible({ timeout: 10_000 })
    await hideToasts(page)
    await page.waitForTimeout(1200)
    const [n, p] = [await nudge.boundingBox(), await panel.boundingBox()]
    console.log(`QA ${BUILD} nudge=${JSON.stringify(n)} panel=${JSON.stringify(p)} overlap=${overlaps(n!, p!)}`)
    await page.screenshot({ path: `${SHOTS}/${BUILD}-agent-panel.png` })
    if (BUILD === 'branch') expect(overlaps(n!, p!)).toBe(false)
    else expect(overlaps(n!, p!)).toBe(true)
  })

  test.describe('sidebar on the right', () => {
    test.use({
      initialSettings: {
        'Comfy.TutorialCompleted': false,
        'Comfy.OnboardingCoachmarks.Seen': ['appMode'],
        'Comfy.Sidebar.Location': 'right'
      }
    })

    test('nudge opens toward the canvas', async ({ comfyPage }) => {
      const { page } = comfyPage
      await skipTourToNudge(page)
      const panel = page.locator('#agent-panel-root')
      const nudge = page.getByTestId('first-run-nudge')
      await expect(nudge).toBeVisible({ timeout: 10_000 })
      await hideToasts(page)
      await page.waitForTimeout(1200)
      const [n, p] = [await nudge.boundingBox(), await panel.boundingBox()]
      console.log(`QA right-sidebar nudge=${JSON.stringify(n)} panel=${JSON.stringify(p)}`)
      await page.screenshot({ path: `${SHOTS}/${BUILD}-right-sidebar.png` })
      expect(overlaps(n!, p!)).toBe(false)
    })
  })

  test('waits while a sidebar panel is open', async ({ comfyPage }) => {
    const { page } = comfyPage
    const nudge = page.getByTestId('first-run-nudge')
    await skipTourToNudge(page)
    await page.getByTestId('node-library-tab-button').click()
    await page.waitForTimeout(3000)
    await hideToasts(page)
    await expect(nudge).toBeHidden()
    await page.screenshot({ path: `${SHOTS}/${BUILD}-panel-open-waits.png` })
    await page.getByTestId('node-library-tab-button').click()
    await expect(nudge).toBeVisible({ timeout: 10_000 })
    await page.waitForTimeout(1200)
    await page.screenshot({ path: `${SHOTS}/${BUILD}-panel-closed-shows.png` })
  })

  test('waits on a narrow window', async ({ comfyPage }) => {
    const { page } = comfyPage
    const nudge = page.getByTestId('first-run-nudge')
    await skipTourToNudge(page)
    await page.setViewportSize({ width: 700, height: 900 })
    await page.waitForTimeout(3000)
    await hideToasts(page)
    await expect(nudge).toBeHidden()
    await page.screenshot({ path: `${SHOTS}/${BUILD}-narrow-waits.png` })
    await page.setViewportSize({ width: 1440, height: 900 })
    await expect(nudge).toBeVisible({ timeout: 10_000 })
  })
})
