import { once } from 'node:events'
import { readFileSync } from 'node:fs'
import { createServer } from 'node:http'
import { fileURLToPath } from 'node:url'

import type { Route } from '@playwright/test'
import { test as base, expect } from '@playwright/test'

function assetPath(relativePath: string) {
  return fileURLToPath(new URL(relativePath, import.meta.url))
}

const IMAGE_PLACEHOLDER = assetPath('../assets/placeholder-1x1.webp')
const VIDEO_PLACEHOLDER = assetPath('../assets/placeholder.webm')
const INTER_FONT = readFileSync(
  assetPath('../assets/inter-latin.woff2')
).toString('base64')

const ANALYTICS_HOSTS = new Set([
  'www.googletagmanager.com',
  't.comfy.org',
  'va.vercel-scripts.com',
  'cdp.customer.io'
])
const EMBED_HOSTS = new Set([
  'www.youtube.com',
  'www.youtube-nocookie.com',
  'demo.arcade.software'
])
const SCRIPT_HOSTS = new Set(['js-na2.hsforms.net'])
const GITHUB_ATTACHMENT_URLS = new Set([
  'https://github.com/user-attachments/assets/07c6b3bf-9aa3-49b7-b8ad-1b4300802473',
  'https://github.com/user-attachments/assets/916211b0-5da9-4c91-b817-bc898a36cfca',
  'https://github.com/user-attachments/assets/f58091d4-909e-44e2-b0bc-5499a8f2b468',
  'https://github.com/user-attachments/assets/049b928c-2366-4f47-8f8d-108133723658'
])
const MEDIA_PATTERNS = [
  /^https:\/\/media\.comfy\.org\/website\/comfy-agent\/[^/?]+\.svg(?:\?.*)?$/i,
  /^https:\/\/(?:media|comfy-hub-assets)\.comfy\.org\/.*\.(?:webp|webm|mp4|png|jpg|jpeg|gif|avif|vtt)(?:\?.*)?$/i,
  /^https:\/\/cloud\.comfy\.org\/templates\/[^/]+\.(?:webp|png|jpg|jpeg|gif|avif)(?:\?.*)?$/i,
  /^https:\/\/raw\.githubusercontent\.com\/Comfy-Org\/workflow_templates\/main\/templates\/.*\.(?:webp|webm|mp4|png|jpg|jpeg|gif|avif|vtt)(?:\?.*)?$/i,
  /^https:\/\/cdn\.jsdelivr\.net\/gh\/Comfy-Org\/workflow_templates@(?:main|[0-9a-f]{40})\/(?:input|output|templates)\/.*\.(?:webp|webm|mp4|png|jpg|jpeg|gif|avif|vtt)(?:\?.*)?$/i,
  /^https:\/\/assets\.sync\.so\/docs\/example-(?:audio\.wav|video\.mp4)$/i
]
const NODE_IMAGE_HOSTS = new Set([
  'avatars.githubusercontent.com',
  'raw.githubusercontent.com'
])
const VIDEO_PATTERN = /\.(webm|mp4)(\?|$)/i
const AUDIO_PATTERN = /\.wav(\?|$)/i
const SUBTITLE_PATTERN = /\.vtt(\?|$)/i

async function fulfillMedia(route: Route) {
  const url = route.request().url()
  if (VIDEO_PATTERN.test(url))
    return route.fulfill({ path: VIDEO_PLACEHOLDER, status: 200 })

  if (AUDIO_PATTERN.test(url))
    return route.fulfill({ status: 200, contentType: 'audio/wav', body: '' })

  if (SUBTITLE_PATTERN.test(url))
    return route.fulfill({
      status: 200,
      contentType: 'text/vtt',
      body: 'WEBVTT\n'
    })

  await route.fulfill({ path: IMAGE_PLACEHOLDER, status: 200 })
}

function isNodeImage(route: Route, url: URL): boolean {
  return (
    NODE_IMAGE_HOSTS.has(url.hostname) &&
    route.request().resourceType() === 'image'
  )
}

type ExternalRouteRule = {
  matches: (route: Route, url: URL) => boolean
  handle: (route: Route) => Promise<unknown>
}

const EXTERNAL_ROUTE_RULES: readonly ExternalRouteRule[] = [
  {
    matches: (_route, url) => ANALYTICS_HOSTS.has(url.hostname),
    handle: (route) => route.abort('blockedbyclient')
  },
  {
    matches: (_route, url) => EMBED_HOSTS.has(url.hostname),
    handle: (route) => route.fulfill({ contentType: 'text/html', body: '' })
  },
  {
    matches: (route, url) =>
      url.hostname === 'apis.google.com' &&
      url.pathname === '/js/api.js' &&
      route.request().resourceType() === 'script',
    handle: (route) =>
      route.fulfill({ contentType: 'text/javascript', body: '' })
  },
  {
    matches: (_route, url) => SCRIPT_HOSTS.has(url.hostname),
    handle: (route) =>
      route.fulfill({ contentType: 'text/javascript', body: '' })
  },
  {
    matches: (route, url) =>
      route.request().resourceType() === 'image' &&
      GITHUB_ATTACHMENT_URLS.has(url.href),
    handle: fulfillMedia
  },
  {
    matches: (_route, url) => url.hostname === 'fonts.googleapis.com',
    handle: (route) =>
      route.fulfill({
        contentType: 'text/css',
        body: `@font-face {
            font-family: 'Inter';
            font-style: normal;
            font-weight: 100 900;
            font-display: swap;
            src: url(data:font/woff2;base64,${INTER_FONT}) format('woff2');
          }`
      })
  },
  {
    matches: (_route, url) =>
      MEDIA_PATTERNS.some((pattern) => pattern.test(url.href)),
    handle: fulfillMedia
  },
  {
    matches: isNodeImage,
    handle: (route) => route.fulfill({ path: IMAGE_PLACEHOLDER })
  },
  {
    matches: (_route, url) =>
      url.hostname.endsWith('cloud.comfy.org') &&
      url.pathname === '/api/features',
    handle: (route) =>
      route.fulfill({
        contentType: 'application/json',
        headers: { 'access-control-allow-origin': '*' },
        body: '{}'
      })
  }
]

async function handleAllowedExternalRequest(route: Route, url: URL) {
  const rule = EXTERNAL_ROUTE_RULES.find((candidate) =>
    candidate.matches(route, url)
  )
  if (!rule) return false

  await rule.handle(route)
  return true
}

export const test = base.extend({
  serviceWorkers: 'block',
  proxy: async ({ baseURL }, use) => {
    if (!baseURL) throw new Error('Website tests require a local baseURL')
    await using server = createServer((_request, response) => {
      response.writeHead(502).end()
    })
    server.on('connect', (_request, socket) => socket.destroy())
    server.listen(0, '127.0.0.1')
    await once(server, 'listening')
    const address = server.address()
    if (!address || typeof address === 'string')
      throw new Error('Expected a TCP address for the deny proxy')
    await use({
      server: `http://127.0.0.1:${address.port}`,
      bypass: new URL(baseURL).hostname
    })
  },
  context: async ({ context, baseURL }, use) => {
    if (!baseURL) throw new Error('Website tests require a local baseURL')
    const localOrigin = new URL(baseURL).origin
    const unexpectedRequests = new Set<string>()

    await context.route('**/*', async (route) => {
      const url = new URL(route.request().url())
      if (url.origin === localOrigin) return route.continue()
      if (await handleAllowedExternalRequest(route, url)) return

      unexpectedRequests.add(url.href)
      return route.abort('blockedbyclient')
    })
    await context.routeWebSocket('**/*', (socket) => {
      unexpectedRequests.add(socket.url())
      return socket.close()
    })

    await use(context)
    expect([...unexpectedRequests], 'Unexpected external requests').toEqual([])
  }
})
