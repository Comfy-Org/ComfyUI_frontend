import type { BrowserContext, Page } from '@playwright/test'
import { expect } from '@playwright/test'

import { test } from '../fixtures/blockExternalMedia'
import { waitForIsland } from '../fixtures/islands'
import { stubWorkshopFlags } from '../fixtures/workshopFlags'

type Route = 'R1' | 'R2' | 'R3' | 'R4' | 'R5' | 'R6' | 'R7' | 'R12' | 'R14'
type Attack =
  | 'S1'
  | 'S2'
  | 'S3'
  | 'S5'
  | 'S6'
  | 'S8'
  | 'I1'
  | 'I2'
  | 'I3'
  | 'I5'
  | 'I8'
  | 'I9'
  | 'A1'
  | 'A2'
  | 'A3'
  | 'A5'
  | 'V2'
  | 'V3'
  | 'iOS4'
type Event =
  | 'back'
  | 'forward'
  | 'reload'
  | 'go-offline'
  | 'go-online'
  | 'hide-resume'
type Reach = 'populated' | 'stale' | 'offline'

interface Row {
  cell: string
  route: Route | 'R15' | 'R17' | 'R18' | 'R25'
  attack: Attack
  engine: 'chromium' | 'webkit'
  viewport: string
  touch: boolean
  dark: boolean
  reduce: boolean
  zh: boolean
  reach?: Reach
  events?: Event[]
}

const HUB = '/hub/models/'
const WORKFLOWS = '/hub/workflows/'

const r = (
  cell: string,
  route: Row['route'],
  attack: Attack,
  env: string,
  extra: Partial<Row> = {}
): Row => {
  const [engine, viewport, input, theme, motion, loc] = env.split(' ')
  return {
    cell,
    route,
    attack,
    engine: engine as Row['engine'],
    viewport,
    touch: input === 'touch',
    dark: theme === 'dark',
    reduce: motion === 'reduce',
    zh: loc === 'zh',
    ...extra
  }
}

// env: engine viewport input theme motion locale
const rows: Row[] = [
  r('TP1-R1-S1', 'R1', 'S1', 'chromium 320x568 mouse dark normal zh'),
  r('TP1-R1-S2', 'R1', 'S2', 'webkit 390x844 touch light reduce en'),
  r('TP1-R1-S3', 'R1', 'S3', 'chromium 768x1024 touch dark normal en'),
  r('TP1-R1-S5', 'R1', 'S5', 'webkit 1920x1080 mouse dark reduce zh'),
  r('TP1-R1-S6', 'R1', 'S6', 'chromium 1536x864 mouse light normal zh'),
  r('TP1-R1-S8', 'R1', 'S8', 'chromium 1280x800 mouse dark reduce en'),
  r('TP1-R1-I1', 'R1', 'I1', 'webkit 768x1024 mouse light normal zh', {
    reach: 'populated',
    events: ['go-offline']
  }),
  r('TP1-R1-I2', 'R1', 'I2', 'chromium 390x844 touch dark normal zh'),
  r('TP1-R1-I3', 'R1', 'I3', 'webkit 320x568 mouse light reduce en'),
  r('TP1-R1-I5', 'R1', 'I5', 'webkit 1280x800 mouse light normal zh'),
  r('TP1-R1-I8', 'R1', 'I8', 'webkit 1536x864 mouse dark reduce en'),
  r('TP1-R1-I9', 'R1', 'I9', 'chromium 1920x1080 mouse light normal en'),
  r('TP1-R1-A1', 'R1', 'A1', 'webkit 768x1024 touch dark reduce zh'),
  r('TP1-R1-A2', 'R1', 'A2', 'chromium 390x844 mouse dark reduce zh'),
  r('TP1-R1-A3', 'R1', 'A3', 'chromium 320x568 touch dark normal zh'),
  r('TP1-R1-A5', 'R1', 'A5', 'chromium 320x568 mouse dark normal zh'),
  r('TP1-R1-V2', 'R1', 'V2', 'webkit 390x844 touch light reduce en'),
  r('TP1-R1-V3', 'R1', 'V3', 'chromium 768x1024 touch dark normal en'),
  r('TP1-R1-iOS4', 'R1', 'iOS4', 'webkit 390x844 touch light reduce en'),
  r('TP1-R2-S6', 'R2', 'S6', 'chromium 1536x864 mouse light normal zh'),
  r('TP1-R3-S6', 'R3', 'S6', 'chromium 1280x800 mouse dark reduce en'),
  r('TP1-R5-S6', 'R5', 'S6', 'webkit 768x1024 mouse light normal zh', {
    reach: 'populated',
    events: ['back']
  }),
  r('TP1-R6-S6', 'R6', 'S6', 'chromium 390x844 touch dark normal zh', {
    reach: 'populated',
    events: ['back', 'forward']
  }),
  r('TP1-R7-S6', 'R7', 'S6', 'webkit 320x568 mouse light reduce en'),
  r('TP1-R12-S6', 'R12', 'S6', 'webkit 1280x800 mouse light normal zh'),
  r('TP1-R14-S6', 'R14', 'S6', 'webkit 1536x864 mouse dark reduce en'),
  r('TP1-R15-S6', 'R15', 'S6', 'chromium 1920x1080 mouse light normal en'),
  r('TP1-R17-S6', 'R17', 'S6', 'webkit 768x1024 touch dark reduce zh'),
  r('TP1-R18-S6', 'R18', 'S6', 'chromium 390x844 mouse dark reduce zh'),
  r('TP1-R25-S6', 'R25', 'S6', 'chromium 320x568 touch dark normal zh'),
  r('TP1-R4-S6-s6', 'R4', 'S6', 'chromium 1280x800 mouse dark reduce en', {
    reach: 'populated',
    events: ['reload']
  }),
  r('TP1-R17-I5-s10', 'R17', 'I5', 'webkit 1280x800 mouse light normal zh', {
    reach: 'populated',
    events: ['hide-resume']
  }),
  r('TP1-R1-I1-s16', 'R1', 'I1', 'chromium 320x568 mouse dark normal zh', {
    reach: 'offline',
    events: ['go-online']
  }),
  r('TP1-R4-S6-s17', 'R4', 'S6', 'webkit 390x844 touch light reduce en', {
    reach: 'stale',
    events: ['reload']
  }),
  r('TP1-R1-I1-s18', 'R1', 'I1', 'chromium 768x1024 touch dark normal en', {
    reach: 'stale',
    events: ['go-offline']
  }),
  r('TP1-R5-S6-s19', 'R5', 'S6', 'webkit 1920x1080 mouse dark reduce zh', {
    reach: 'stale',
    events: ['back']
  }),
  r('TP1-R6-S6-s20', 'R6', 'S6', 'chromium 1536x864 mouse light normal zh', {
    reach: 'stale',
    events: ['back', 'forward']
  }),
  r('TP1-R17-I5-s21', 'R17', 'I5', 'chromium 1280x800 mouse dark reduce en', {
    reach: 'stale',
    events: ['hide-resume']
  }),
  r('TP1-R5-S6-s61', 'R5', 'S6', 'webkit 768x1024 mouse light normal zh', {
    reach: 'populated',
    events: ['back', 'reload']
  }),
  r('TP1-R5-S6-s62', 'R5', 'S6', 'chromium 390x844 touch dark normal zh', {
    reach: 'populated',
    events: ['back', 'go-offline']
  }),
  r('TP1-R6-S6-s63', 'R6', 'S6', 'webkit 320x568 mouse light reduce en', {
    reach: 'populated',
    events: ['back', 'forward', 'reload']
  }),
  r('TP1-R6-S6-s64', 'R6', 'S6', 'webkit 1280x800 mouse light normal zh', {
    reach: 'populated',
    events: ['back', 'forward', 'go-offline']
  })
]

const tab = (page: Page, name: 'models' | 'workflows' | 'apps') =>
  page.getByTestId(`catalogue-tab-${name}`)

async function expectTabsReady(page: Page) {
  await expect(page.getByTestId('catalogue-tabs')).toBeVisible()
  await expect(tab(page, 'workflows')).toHaveAttribute('href', WORKFLOWS)
}

// --- entry routes ---------------------------------------------------------

const entry: Record<string, (page: Page) => Promise<void>> = {
  // Home first, then the designed hop into the hub models page.
  R1: async (page) => {
    await page.goto('/')
    await page.goto(HUB)
  },
  R2: async (page) => {
    await page.goto(HUB)
  },
  R3: async (page) => {
    await page.goto('/hub/models?utm_x=1&extra=a&extra=b#top')
  },
  R4: async (page) => {
    await page.goto(HUB)
  },
  R5: async (page) => {
    await page.goto(HUB)
  },
  R6: async (page) => {
    await page.goto('/')
    await page.goto(HUB)
  },
  R7: async (page) => {
    await page.goto(HUB)
  },
  R12: async (page) => {
    await page.goto(`${HUB}?utm_source=email&ref=abc#models`)
  },
  R14: async (page) => {
    await page.goto(HUB)
  },
  R15: async (page) => {
    await page.goto(HUB)
  },
  R17: async (page) => {
    await page.goto(HUB)
  },
  // A 404 page first, then the hub.
  R18: async (page) => {
    await page.goto('/hub/does-not-exist-404/')
    await page.goto(HUB)
  },
  R25: async (page) => {
    await page.goto(HUB)
  }
}

// --- state-table events ---------------------------------------------------

async function hideResume(page: Page) {
  await page.evaluate(() => {
    Object.defineProperty(document, 'visibilityState', {
      configurable: true,
      get: () => 'hidden'
    })
    Object.defineProperty(document, 'hidden', {
      configurable: true,
      get: () => true
    })
    document.dispatchEvent(new Event('visibilitychange'))
  })
  await page.evaluate(() => {
    Object.defineProperty(document, 'visibilityState', {
      configurable: true,
      get: () => 'visible'
    })
    Object.defineProperty(document, 'hidden', {
      configurable: true,
      get: () => false
    })
    document.dispatchEvent(new Event('visibilitychange'))
  })
}

async function fire(page: Page, context: BrowserContext, ev: Event) {
  switch (ev) {
    case 'back':
      await page.goBack()
      break
    case 'forward':
      await page.goForward()
      break
    case 'reload':
      await page.reload()
      break
    case 'go-offline':
      await context.setOffline(true)
      break
    case 'go-online':
      await context.setOffline(false)
      break
    case 'hide-resume':
      await hideResume(page)
      break
  }
}

// Reach the start state, and fire the events. Returns whether we are offline.
async function runStates(page: Page, context: BrowserContext, row: Row) {
  let offline = false
  const events = row.events ?? []
  if (row.reach === 'stale') {
    // Follow a link onward, then Back.
    await tab(page, 'apps').click()
    await expect(page).toHaveURL('/hub/apps/')
    await page.goBack()
    await expect(page).toHaveURL(HUB)
  } else if (row.reach === 'offline') {
    await context.setOffline(true)
    offline = true
  }
  for (const ev of events) {
    if (ev === 'back' && row.route === 'R5') {
      // Back needs a page to leave from: follow a link onward first.
      await tab(page, 'apps').click()
      await expect(page).toHaveURL('/hub/apps/')
    }
    if (ev === 'back' && row.route === 'R6' && events[0] === 'back') {
      // Back to leave: the entry already pushed a page before the hub.
    }
    await fire(page, context, ev)
    if (ev === 'go-offline') offline = true
    if (ev === 'go-online') offline = false
    if (ev === 'back' || ev === 'forward' || ev === 'reload') {
      if (!offline) {
        await expect(page.getByTestId('catalogue-tabs')).toBeVisible()
      }
    }
  }
  return offline
}

// --- break attempts -------------------------------------------------------

async function clickToWorkflows(page: Page) {
  const link = tab(page, 'workflows')
  await waitForIsland(page, link).catch(() => link.scrollIntoViewIfNeeded())
  await link.click()
  await expect(page).toHaveURL(WORKFLOWS)
}

async function attack(page: Page, context: BrowserContext, row: Row) {
  switch (row.attack) {
    case 'S1': {
      await tab(page, 'workflows').dblclick()
      await expect(page).toHaveURL(WORKFLOWS)
      // Exactly one effect: one history entry, Back returns to the hub.
      await page.goBack()
      await expect(page).toHaveURL(HUB)
      return
    }
    case 'S2': {
      for (let i = 0; i < 5; i++) {
        await clickToWorkflows(page)
        await page.goBack()
        await expect(page).toHaveURL(HUB)
      }
      await clickToWorkflows(page)
      return
    }
    case 'S3': {
      // Invalid transition: click Workflows while already on its page.
      await page.goto(WORKFLOWS)
      await expect(tab(page, 'workflows')).toHaveAttribute(
        'aria-current',
        'page'
      )
      await tab(page, 'workflows').click()
      await expect(page).toHaveURL(WORKFLOWS)
      return
    }
    case 'S5': {
      // Cancel mid-navigation by going back, then click again.
      await tab(page, 'workflows').click()
      await page.goBack().catch(() => undefined)
      await page.goto(HUB)
      await clickToWorkflows(page)
      return
    }
    case 'S8': {
      await tab(page, 'workflows').click()
      await page.goto(HUB)
      await clickToWorkflows(page)
      return
    }
    case 'I1': {
      // Offline: assert the tab stays and still points at the workflows page.
      await expectTabsReady(page)
      return
    }
    case 'I2': {
      await context.route('**/*.{png,jpg,webp,svg}', async (route) => {
        await new Promise((resolve) => setTimeout(resolve, 300))
        await route.abort('failed')
      })
      await clickToWorkflows(page)
      return
    }
    case 'I3': {
      await context.route('**/api/**', (route) =>
        route.fulfill({ status: 500, body: 'boom' })
      )
      await clickToWorkflows(page)
      return
    }
    case 'I5': {
      await hideResume(page)
      await clickToWorkflows(page)
      return
    }
    case 'I8': {
      await clickToWorkflows(page)
      return
    }
    case 'I9': {
      const cdp = await context.newCDPSession(page)
      await cdp.send('Emulation.setCPUThrottlingRate', { rate: 6 })
      await clickToWorkflows(page)
      return
    }
    case 'A1': {
      await tab(page, 'workflows').focus()
      await expect(tab(page, 'workflows')).toBeFocused()
      await page.keyboard.press('Enter')
      await expect(page).toHaveURL(WORKFLOWS)
      return
    }
    case 'A2': {
      const nav = page.getByRole('navigation', { name: /.+/ })
      await expect(nav.first()).toBeVisible()
      const group = page.getByTestId('catalogue-tabs')
      // Everything interactive in the control has an accessible name.
      const buttons = await group.getByRole('button').count()
      await expect(group.getByRole('button', { name: /\S/ })).toHaveCount(
        buttons
      )
      await expect(group.getByRole('link', { name: /\S/ })).toHaveCount(3)
      await clickToWorkflows(page)
      return
    }
    case 'A3': {
      await page.setViewportSize({ width: 320, height: 256 })
      await expect(page.getByTestId('catalogue-tabs')).toBeVisible()
      const overflow = await page.evaluate(
        () => document.documentElement.scrollWidth - window.innerWidth
      )
      expect(overflow).toBeLessThanOrEqual(0)
      await clickToWorkflows(page)
      return
    }
    case 'A5': {
      await page.emulateMedia({ forcedColors: 'active', contrast: 'more' })
      await clickToWorkflows(page)
      return
    }
    case 'V2': {
      const { width, height } = page.viewportSize()!
      await page.setViewportSize({ width: height, height: width })
      await expect(tab(page, 'workflows')).toBeVisible()
      await clickToWorkflows(page)
      return
    }
    case 'V3': {
      for (const name of ['models', 'workflows', 'apps'] as const) {
        const box = await tab(page, name).boundingBox()
        expect(box!.height).toBeGreaterThanOrEqual(24)
        expect(box!.width).toBeGreaterThanOrEqual(24)
      }
      await tab(page, 'workflows').scrollIntoViewIfNeeded()
      await tab(page, 'workflows').tap()
      await expect(page).toHaveURL(WORKFLOWS)
      return
    }
    case 'iOS4': {
      await clickToWorkflows(page)
      await page.goBack()
      await expect(page).toHaveURL(HUB)
      await clickToWorkflows(page)
      return
    }
  }
}

// --- routes with their own final action -----------------------------------

async function routeFinal(page: Page, row: Row) {
  switch (row.route) {
    case 'R7': {
      await page.goto('/')
      await page.goBack()
      await expect(page).toHaveURL(HUB)
      await clickToWorkflows(page)
      return true
    }
    case 'R14': {
      await tab(page, 'models').focus()
      await page.keyboard.press('Tab')
      await expect(tab(page, 'workflows')).toBeFocused()
      await page.keyboard.press('Enter')
      await expect(page).toHaveURL(WORKFLOWS)
      return true
    }
    case 'R15': {
      await tab(page, 'workflows').click()
      await expect(page).toHaveURL(WORKFLOWS)
      return true
    }
    case 'R25': {
      // Triggers: pointer click, then keyboard Enter on a fresh load.
      await clickToWorkflows(page)
      await page.goto(HUB)
      await tab(page, 'workflows').focus()
      await page.keyboard.press('Enter')
      await expect(page).toHaveURL(WORKFLOWS)
      return true
    }
    case 'R17': {
      await hideResume(page)
      return false
    }
    default:
      return false
  }
}

for (const row of rows) {
  const [w, h] = row.viewport.split('x').map(Number)
  test.describe(row.cell, () => {
    test.use({
      viewport: { width: w, height: h },
      colorScheme: row.dark ? 'dark' : 'light',
      reducedMotion: row.reduce ? 'reduce' : 'no-preference',
      locale: row.zh ? 'zh-CN' : 'en-US',
      hasTouch: row.touch,
      timezoneId: 'UTC'
    })

    test(`[${row.cell}] Workflows tab leads to ${WORKFLOWS} (${row.route}, ${row.attack})`, async ({
      page,
      context,
      browserName
    }) => {
      test.skip(browserName !== row.engine)
      const errors: Error[] = []
      page.on('pageerror', (e) => errors.push(e))

      await stubWorkshopFlags(context, {
        'workshop-enabled': true,
        'workshop-workflows-enabled': true,
        'workshop-apps-enabled': true
      })
      if (row.attack === 'I8') {
        await context.addInitScript(() => {
          for (const k of ['localStorage', 'sessionStorage']) {
            Object.defineProperty(window, k, {
              configurable: true,
              get() {
                throw new DOMException('blocked', 'SecurityError')
              }
            })
          }
        })
      }

      await entry[row.route](page)
      await expectTabsReady(page)
      test.info().annotations.push({
        type: 'precondition',
        description: `landed URL before action: ${new URL(page.url()).pathname}`
      })
      expect(new URL(page.url()).pathname.replace(/\/$/, '')).toBe(
        HUB.replace(/\/$/, '')
      )

      let done = false
      let offline = false
      if (row.events || row.reach) {
        offline = await runStates(page, context, row)
        if (!offline) {
          await expectTabsReady(page)
          await clickToWorkflows(page)
        } else {
          // Offline: a recoverable state; the tab keeps its target.
          await expectTabsReady(page)
          await context.setOffline(false)
          await clickToWorkflows(page)
        }
        done = true
      }
      if (!done) {
        const handled = await routeFinal(page, row)
        if (row.route === 'R17') {
          await expectTabsReady(page)
          await clickToWorkflows(page)
        } else if (!handled) {
          await attack(page, context, row)
        }
      }
      if (row.attack === 'I1' && !row.events) {
        await context.setOffline(true)
        await expectTabsReady(page)
        await context.setOffline(false)
        await clickToWorkflows(page)
      }
      expect(errors.map((e) => e.message)).toEqual([])
    })
  })
}
